import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = { title: "Bilio", description: "Arkadaşlarla gerçek zamanlı bilgi yarışması" };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) { return <html lang="tr"><body>{children}</body></html>; }
