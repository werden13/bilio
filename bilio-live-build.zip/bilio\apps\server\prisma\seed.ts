import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

async function main() {
  if (await prisma.question.count()) return;
  await prisma.question.createMany({
    data: [
      { text: "Türkiye'nin başkenti neresidir?", options: ["İstanbul", "Ankara", "İzmir", "Bursa"], correctIndex: 1, category: "Coğrafya", difficulty: "Kolay", timeLimit: 20 },
      { text: "Güneş Sistemi'ndeki en büyük gezegen hangisidir?", options: ["Mars", "Dünya", "Jüpiter", "Satürn"], correctIndex: 2, category: "Bilim", difficulty: "Kolay", timeLimit: 20 },
      { text: "HTML kısaltmasının açılımı nedir?", options: ["HyperText Markup Language", "HighText Machine Language", "Hyperlink Text Main Language", "Home Tool Markup Language"], correctIndex: 0, category: "Teknoloji", difficulty: "Orta", timeLimit: 20 }
    ]
  });
}

main().finally(async () => prisma.$disconnect());
