import BilioApp from "@/components/BilioApp";
export default function HomePage() { return <BilioApp />; }
