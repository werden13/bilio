# Bilio

Bilio, arkadaşlarla oynanabilen gerçek zamanlı bir bilgi yarışması web uygulamasıdır.

## Stack
- Next.js + React + TypeScript
- Tailwind CSS
- Node.js + Express + Socket.IO
- PostgreSQL + Prisma
- npm workspaces monorepo

## Yapı
- `apps/web`: Next.js istemci
- `apps/server`: Socket.IO sunucusu ve Prisma
- `packages/shared`: ortak tipler ve event sözleşmeleri

## Çalıştırma
1. `docker compose up -d db`
2. `npm install`
3. `cp apps/server/.env.example apps/server/.env`
4. `cp apps/web/.env.example apps/web/.env.local`
5. `npm run db:generate`
6. `npm run db:migrate -- --name init`
7. `npm run db:seed`
8. `npm run dev`

Web: http://localhost:3000
Socket/API: http://localhost:4000
