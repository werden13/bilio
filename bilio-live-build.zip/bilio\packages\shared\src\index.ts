export type Player = {
  id: string;
  name: string;
  score: number;
  isHost?: boolean;
};

export type PublicQuestion = {
  id: string;
  text: string;
  options: string[];
  category?: string | null;
  difficulty?: string | null;
  timeLimit: number;
};

export type RoomSnapshot = {
  code: string;
  status: "LOBBY" | "PLAYING" | "FINISHED";
  players: Player[];
  currentQuestion?: PublicQuestion | null;
  questionIndex: number;
  totalQuestions: number;
};

export interface ClientToServerEvents {
  "room:create": (payload: { playerName: string }, callback: (result: { ok: boolean; room?: RoomSnapshot; playerId?: string; error?: string }) => void) => void;
  "room:join": (payload: { code: string; playerName: string }, callback: (result: { ok: boolean; room?: RoomSnapshot; playerId?: string; error?: string }) => void) => void;
  "game:start": (payload: { code: string; playerId: string }, callback: (result: { ok: boolean; error?: string }) => void) => void;
  "answer:submit": (payload: { code: string; playerId: string; optionIndex: number }, callback: (result: { ok: boolean; correct?: boolean; score?: number; error?: string }) => void) => void;
}

export interface ServerToClientEvents {
  "room:update": (room: RoomSnapshot) => void;
  "game:started": (room: RoomSnapshot) => void;
  "question:new": (room: RoomSnapshot) => void;
  "game:finished": (room: RoomSnapshot) => void;
  "player:left": (payload: { playerId: string; room: RoomSnapshot }) => void;
}
