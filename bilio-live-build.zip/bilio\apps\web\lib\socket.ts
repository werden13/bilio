"use client";
import { io, type Socket } from "socket.io-client";
import type { ClientToServerEvents, ServerToClientEvents } from "@bilio/shared";
let socket: Socket<ServerToClientEvents, ClientToServerEvents> | null = null;
export function getSocket() { if (!socket) socket = io(process.env.NEXT_PUBLIC_SOCKET_URL ?? "http://localhost:4000", { autoConnect: true }); return socket; }
