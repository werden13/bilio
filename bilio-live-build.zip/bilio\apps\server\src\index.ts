import "dotenv/config";
import express from "express";
import cors from "cors";
import { createServer } from "http";
import { Server } from "socket.io";
import type { ClientToServerEvents, ServerToClientEvents } from "@bilio/shared";
import { advanceQuestion, createRoom, getRoomSnapshot, joinRoom, startGame, submitAnswer } from "./game/roomService";
import { prisma } from "./db";

const PORT = Number(process.env.PORT ?? 4000);
const WEB_ORIGIN = process.env.WEB_ORIGIN ?? "http://localhost:3000";
const app = express();
app.use(cors({ origin: WEB_ORIGIN }));
app.use(express.json());
app.get("/health", (_req, res) => res.json({ ok: true, service: "bilio-server" }));

const httpServer = createServer(app);
const io = new Server<ClientToServerEvents, ServerToClientEvents>(httpServer, { cors: { origin: WEB_ORIGIN, methods: ["GET", "POST"] } });
const questionTimers = new Map<string, NodeJS.Timeout>();

function scheduleAdvance(code: string, seconds: number) {
  const previous = questionTimers.get(code);
  if (previous) clearTimeout(previous);
  const timer = setTimeout(async () => {
    try {
      const result = await advanceQuestion(code);
      if (result.finished) { io.to(code).emit("game:finished", result.room); questionTimers.delete(code); }
      else { io.to(code).emit("question:new", result.room); scheduleAdvance(code, result.room.currentQuestion?.timeLimit ?? 20); }
    } catch (error) { console.error(error); }
  }, seconds * 1000);
  questionTimers.set(code, timer);
}

io.on("connection", socket => {
  socket.on("room:create", async ({ playerName }, callback) => {
    try {
      if (!playerName.trim()) throw new Error("Oyuncu adı gerekli.");
      const result = await createRoom(playerName, socket.id);
      await socket.join(result.room.code); callback({ ok: true, ...result }); io.to(result.room.code).emit("room:update", result.room);
    } catch (error) { callback({ ok: false, error: error instanceof Error ? error.message : "Bilinmeyen hata" }); }
  });
  socket.on("room:join", async ({ code, playerName }, callback) => {
    try {
      if (!playerName.trim()) throw new Error("Oyuncu adı gerekli.");
      const result = await joinRoom(code.trim().toUpperCase(), playerName, socket.id);
      await socket.join(result.room.code); callback({ ok: true, ...result }); io.to(result.room.code).emit("room:update", result.room);
    } catch (error) { callback({ ok: false, error: error instanceof Error ? error.message : "Bilinmeyen hata" }); }
  });
  socket.on("game:start", async ({ code, playerId }, callback) => {
    try { const room = await startGame(code, playerId); callback({ ok: true }); io.to(code).emit("game:started", room); scheduleAdvance(code, room.currentQuestion?.timeLimit ?? 20); }
    catch (error) { callback({ ok: false, error: error instanceof Error ? error.message : "Bilinmeyen hata" }); }
  });
  socket.on("answer:submit", async ({ code, playerId, optionIndex }, callback) => {
    try { const result = await submitAnswer(code, playerId, optionIndex); callback({ ok: true, ...result }); io.to(code).emit("room:update", await getRoomSnapshot(code)); }
    catch (error) { callback({ ok: false, error: error instanceof Error ? error.message : "Bilinmeyen hata" }); }
  });
  socket.on("disconnect", async () => {
    try {
      const player = await prisma.player.findFirst({ where: { socketId: socket.id } }); if (!player) return;
      const room = await prisma.room.findUnique({ where: { id: player.roomId } }); await prisma.player.delete({ where: { id: player.id } }); if (!room) return;
      const remaining = await prisma.player.findMany({ where: { roomId: room.id }, orderBy: { createdAt: "asc" } });
      if (!remaining.length) { await prisma.room.delete({ where: { id: room.id } }); const t = questionTimers.get(room.code); if (t) clearTimeout(t); questionTimers.delete(room.code); return; }
      if (player.isHost && !remaining.some(p => p.isHost)) await prisma.player.update({ where: { id: remaining[0].id }, data: { isHost: true } });
      const snapshot = await getRoomSnapshot(room.code); io.to(room.code).emit("player:left", { playerId: player.id, room: snapshot }); io.to(room.code).emit("room:update", snapshot);
    } catch (error) { console.error("disconnect cleanup error", error); }
  });
});

httpServer.listen(PORT, () => console.log(`Bilio server running on http://localhost:${PORT}`));
