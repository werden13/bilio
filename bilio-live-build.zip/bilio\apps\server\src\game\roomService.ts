import type { PublicQuestion, RoomSnapshot } from "@bilio/shared";
import { prisma } from "../db";
import { generateRoomCode } from "../utils/roomCode";

async function uniqueCode() {
  for (let i = 0; i < 20; i += 1) {
    const code = generateRoomCode();
    if (!await prisma.room.findUnique({ where: { code } })) return code;
  }
  throw new Error("Oda kodu üretilemedi.");
}

function toPublicQuestion(question: any): PublicQuestion {
  return { id: question.id, text: question.text, options: question.options as string[], category: question.category, difficulty: question.difficulty, timeLimit: question.timeLimit };
}

export async function createRoom(playerName: string, socketId: string) {
  const code = await uniqueCode();
  const room = await prisma.room.create({ data: { code, players: { create: { name: playerName.trim(), isHost: true, socketId } } }, include: { players: true } });
  return { room: await getRoomSnapshot(code), playerId: room.players[0].id };
}

export async function joinRoom(code: string, playerName: string, socketId: string) {
  const room = await prisma.room.findUnique({ where: { code: code.toUpperCase() } });
  if (!room) throw new Error("Oda bulunamadı.");
  if (room.status !== "LOBBY") throw new Error("Oyun zaten başladı.");
  const player = await prisma.player.create({ data: { name: playerName.trim(), roomId: room.id, socketId } });
  return { room: await getRoomSnapshot(room.code), playerId: player.id };
}

export async function getRoomSnapshot(code: string): Promise<RoomSnapshot> {
  const room = await prisma.room.findUnique({ where: { code }, include: { players: { orderBy: { createdAt: "asc" } } } });
  if (!room) throw new Error("Oda bulunamadı.");
  const questions = await prisma.question.findMany({ orderBy: { createdAt: "asc" } });
  const current = room.status === "PLAYING" ? questions[room.currentQuestion] : undefined;
  return { code: room.code, status: room.status, players: room.players.map(p => ({ id: p.id, name: p.name, score: p.score, isHost: p.isHost })), currentQuestion: current ? toPublicQuestion(current) : null, questionIndex: room.currentQuestion, totalQuestions: questions.length };
}

export async function startGame(code: string, playerId: string) {
  const room = await prisma.room.findUnique({ where: { code }, include: { players: true } });
  if (!room) throw new Error("Oda bulunamadı.");
  const host = room.players.find(p => p.isHost);
  if (!host || host.id !== playerId) throw new Error("Oyunu yalnızca oda sahibi başlatabilir.");
  if (await prisma.question.count() === 0) throw new Error("Soru havuzu boş.");
  await prisma.room.update({ where: { id: room.id }, data: { status: "PLAYING", currentQuestion: 0 } });
  return getRoomSnapshot(code);
}

export async function submitAnswer(code: string, playerId: string, optionIndex: number) {
  const room = await prisma.room.findUnique({ where: { code }, include: { players: true } });
  if (!room || room.status !== "PLAYING") throw new Error("Aktif oyun bulunamadı.");
  const player = room.players.find(p => p.id === playerId);
  if (!player) throw new Error("Oyuncu bulunamadı.");
  const questions = await prisma.question.findMany({ orderBy: { createdAt: "asc" } });
  const question = questions[room.currentQuestion];
  if (!question) throw new Error("Aktif soru bulunamadı.");
  const existing = await prisma.answer.findUnique({ where: { playerId_questionId: { playerId, questionId: question.id } } });
  if (existing) throw new Error("Bu soruyu zaten cevapladın.");
  const correct = optionIndex === question.correctIndex;
  const points = correct ? 100 : 0;
  await prisma.answer.create({ data: { playerId, questionId: question.id, optionIndex, isCorrect: correct, points } });
  if (points) await prisma.player.update({ where: { id: playerId }, data: { score: { increment: points } } });
  return { correct, score: player.score + points };
}

export async function advanceQuestion(code: string) {
  const room = await prisma.room.findUnique({ where: { code } });
  if (!room) throw new Error("Oda bulunamadı.");
  const total = await prisma.question.count();
  const next = room.currentQuestion + 1;
  if (next >= total) {
    await prisma.room.update({ where: { id: room.id }, data: { status: "FINISHED" } });
    return { finished: true, room: await getRoomSnapshot(code) };
  }
  await prisma.room.update({ where: { id: room.id }, data: { currentQuestion: next } });
  return { finished: false, room: await getRoomSnapshot(code) };
}
