import type { NextConfig } from "next";
const nextConfig: NextConfig = { transpilePackages: ["@bilio/shared"] };
export default nextConfig;
