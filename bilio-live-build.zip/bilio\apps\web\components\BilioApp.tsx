"use client";
import { FormEvent, useEffect, useMemo, useState } from "react";
import type { RoomSnapshot } from "@bilio/shared";
import { getSocket } from "@/lib/socket";

export default function BilioApp() {
  const socket = useMemo(() => getSocket(), []);
  const [name, setName] = useState("");
  const [roomCodeInput, setRoomCodeInput] = useState("");
  const [room, setRoom] = useState<RoomSnapshot | null>(null);
  const [playerId, setPlayerId] = useState<string | null>(null);
  const [message, setMessage] = useState("");
  const [answered, setAnswered] = useState(false);

  useEffect(() => {
    const update = (next: RoomSnapshot) => setRoom(next);
    const nextQuestion = (next: RoomSnapshot) => { setRoom(next); setAnswered(false); setMessage(""); };
    const finished = (next: RoomSnapshot) => { setRoom(next); setAnswered(false); setMessage("Oyun bitti!"); };
    socket.on("room:update", update); socket.on("game:started", nextQuestion); socket.on("question:new", nextQuestion); socket.on("game:finished", finished);
    return () => { socket.off("room:update", update); socket.off("game:started", nextQuestion); socket.off("question:new", nextQuestion); socket.off("game:finished", finished); };
  }, [socket]);

  function createRoom(e: FormEvent) { e.preventDefault(); setMessage(""); socket.emit("room:create", { playerName: name }, result => { if (!result.ok || !result.room || !result.playerId) return setMessage(result.error ?? "Oda oluşturulamadı."); setRoom(result.room); setPlayerId(result.playerId); }); }
  function joinRoom(e: FormEvent) { e.preventDefault(); setMessage(""); socket.emit("room:join", { code: roomCodeInput, playerName: name }, result => { if (!result.ok || !result.room || !result.playerId) return setMessage(result.error ?? "Odaya katılınamadı."); setRoom(result.room); setPlayerId(result.playerId); }); }
  function startGame() { if (!room || !playerId) return; socket.emit("game:start", { code: room.code, playerId }, result => { if (!result.ok) setMessage(result.error ?? "Oyun başlatılamadı."); }); }
  function submitAnswer(optionIndex: number) { if (!room || !playerId || answered) return; socket.emit("answer:submit", { code: room.code, playerId, optionIndex }, result => { if (!result.ok) return setMessage(result.error ?? "Cevap gönderilemedi."); setAnswered(true); setMessage(result.correct ? "Doğru! +100 puan" : "Yanlış cevap."); }); }

  const me = room?.players.find(p => p.id === playerId);

  if (!room) return <main className="mx-auto flex min-h-screen max-w-5xl items-center px-6 py-16"><div className="grid w-full gap-8 lg:grid-cols-2"><section className="rounded-3xl border border-white/10 bg-white/5 p-8 shadow-2xl backdrop-blur"><p className="mb-3 text-sm font-bold uppercase tracking-[.3em] text-violet-300">Bilio</p><h1 className="text-5xl font-black tracking-tight">Arkadaşlarınla yarış. En çok sen bil.</h1><p className="mt-5 text-zinc-300">Oda oluştur, kodu arkadaşlarına gönder ve gerçek zamanlı bilgi yarışmasına başla.</p></section><section className="space-y-4"><div className="rounded-3xl border border-white/10 bg-zinc-950/70 p-6"><label className="text-sm text-zinc-400">Oyuncu adı</label><input value={name} onChange={e=>setName(e.target.value)} placeholder="Örn. Pelin" className="mt-2 w-full rounded-2xl border border-white/10 bg-white/5 px-4 py-3 outline-none focus:border-violet-400" /></div><form onSubmit={createRoom} className="rounded-3xl border border-white/10 bg-zinc-950/70 p-6"><h2 className="text-xl font-bold">Yeni oda</h2><button disabled={!name.trim()} className="mt-4 w-full rounded-2xl bg-white px-4 py-3 font-bold text-black disabled:opacity-40">Oda oluştur</button></form><form onSubmit={joinRoom} className="rounded-3xl border border-white/10 bg-zinc-950/70 p-6"><h2 className="text-xl font-bold">Odaya katıl</h2><input value={roomCodeInput} onChange={e=>setRoomCodeInput(e.target.value.toUpperCase())} maxLength={6} placeholder="ODA KODU" className="mt-4 w-full rounded-2xl border border-white/10 bg-white/5 px-4 py-3 uppercase tracking-[.25em] outline-none"/><button disabled={!name.trim() || roomCodeInput.length < 4} className="mt-3 w-full rounded-2xl bg-violet-600 px-4 py-3 font-bold disabled:opacity-40">Katıl</button></form>{message && <p className="text-rose-300">{message}</p>}</section></div></main>;

  if (room.status === "FINISHED") { const ranking = [...room.players].sort((a,b)=>b.score-a.score); return <main className="mx-auto min-h-screen max-w-3xl px-6 py-16"><div className="rounded-3xl border border-white/10 bg-white/5 p-8"><p className="text-violet-300">Oda {room.code}</p><h1 className="mt-2 text-4xl font-black">Sonuçlar</h1><div className="mt-8 space-y-3">{ranking.map((p,i)=><div key={p.id} className="flex items-center justify-between rounded-2xl bg-black/30 p-4"><span className="font-bold">{i+1}. {p.name}</span><span>{p.score} puan</span></div>)}</div></div></main>; }

  if (room.status === "PLAYING" && room.currentQuestion) return <main className="mx-auto min-h-screen max-w-4xl px-6 py-10"><header className="mb-6 flex items-center justify-between text-sm text-zinc-300"><span>Oda: <b>{room.code}</b></span><span>{room.questionIndex+1} / {room.totalQuestions}</span><span>{me?.score ?? 0} puan</span></header><section className="rounded-3xl border border-white/10 bg-white/5 p-8"><p className="text-sm uppercase tracking-widest text-violet-300">{room.currentQuestion.category ?? "Genel"}</p><h1 className="mt-3 text-3xl font-black">{room.currentQuestion.text}</h1><div className="mt-8 grid gap-4 md:grid-cols-2">{room.currentQuestion.options.map((option,index)=><button key={option} onClick={()=>submitAnswer(index)} disabled={answered} className="min-h-24 rounded-2xl border border-white/10 bg-zinc-900 p-5 text-left text-lg font-bold transition hover:-translate-y-0.5 hover:bg-zinc-800 disabled:opacity-50">{String.fromCharCode(65+index)}. {option}</button>)}</div>{message && <p className="mt-6 font-semibold text-violet-200">{message}</p>}</section></main>;

  return <main className="mx-auto min-h-screen max-w-4xl px-6 py-10"><section className="rounded-3xl border border-white/10 bg-white/5 p-8"><p className="text-sm uppercase tracking-widest text-violet-300">Oda kodu</p><div className="mt-2 text-5xl font-black tracking-[.18em]">{room.code}</div><p className="mt-3 text-zinc-400">Arkadaşların bu kodla odaya katılabilir.</p><h2 className="mt-10 text-xl font-bold">Oyuncular ({room.players.length})</h2><div className="mt-4 grid gap-3 sm:grid-cols-2">{room.players.map(p=><div key={p.id} className="rounded-2xl bg-black/30 p-4"><span className="font-bold">{p.name}</span>{p.isHost && <span className="ml-2 text-xs text-violet-300">HOST</span>}</div>)}</div>{me?.isHost ? <button onClick={startGame} className="mt-8 w-full rounded-2xl bg-violet-600 px-5 py-4 text-lg font-black">Oyunu başlat</button> : <p className="mt-8 text-zinc-400">Oda sahibinin oyunu başlatması bekleniyor.</p>}{message && <p className="mt-5 text-rose-300">{message}</p>}</section></main>;
}
